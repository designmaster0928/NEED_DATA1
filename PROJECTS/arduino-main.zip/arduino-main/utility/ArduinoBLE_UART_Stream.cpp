/*
 * Implementation is in ArduinoBLE_UART_Stream.h to avoid making ArduinoBLE a
 * build-time dependency for all projects that use the Firmata library.
 */
