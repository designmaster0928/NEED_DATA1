#include "gfx/legato/generated/le_gen_assets.h"

void legato_preprocessImages(void)
{
    leProcessImage(&mchp_circle, 0xA88D0000, LE_COLOR_MODE_RGBA_8888);
}
