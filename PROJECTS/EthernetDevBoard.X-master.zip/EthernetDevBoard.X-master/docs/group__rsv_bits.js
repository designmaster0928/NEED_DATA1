var group__rsv_bits =
[
    [ "RSV_BYTE2_CARRIER_EVENT_PREVIOUSLY_SEEN", "group__rsv_bits.html#gafcc8915d0220c1ed83eb1147ce4e9e09", null ],
    [ "RSV_BYTE2_CRC_ERROR", "group__rsv_bits.html#gace08d6adf3cc71efe58de192f32e7eed", null ],
    [ "RSV_BYTE2_LENGTH_CHECK_ERROR", "group__rsv_bits.html#ga6357e8c0947cbeac9db63de2eccb0ec7", null ],
    [ "RSV_BYTE2_LENGTH_OUT_OF_RANGE", "group__rsv_bits.html#ga304b3ff7e33f76cb6266a42edc52c013", null ],
    [ "RSV_BYTE2_PACKET_PREVIOUSLY_IGNORED", "group__rsv_bits.html#gabb7a7f4cdbc591010a1e6fd94c444734", null ],
    [ "RSV_BYTE2_RECEIVED_OK", "group__rsv_bits.html#gae48d0c27661f4863ec21153ceb5ad8b2", null ],
    [ "RSV_BYTE3_DRIBBLE_NIBBLE", "group__rsv_bits.html#ga97efdc2e71e9580117ca7b7b38218224", null ],
    [ "RSV_BYTE3_RECEIVED_BROADCAST_PACKET", "group__rsv_bits.html#ga06f2e1468cb53ccaabf5f13d19881f77", null ],
    [ "RSV_BYTE3_RECEIVED_CONTROL_FRAME", "group__rsv_bits.html#ga38e402fa239e391e46b28b5c6681dfe9", null ],
    [ "RSV_BYTE3_RECEIVED_MULTICAST_PACKET", "group__rsv_bits.html#ga8cd28365aea08543683d6477796fad4d", null ],
    [ "RSV_BYTE3_RECEIVED_PAUSE_CONTROL_FRAME", "group__rsv_bits.html#ga79ecf389081d30616847cae6cb5b7a62", null ],
    [ "RSV_BYTE3_RECEIVED_UNKNOWN_OPCODE", "group__rsv_bits.html#ga1d598b4ddbd78ad09795a0f02845c85f", null ],
    [ "RSV_BYTE3_RECEIVED_VLAN", "group__rsv_bits.html#gaa1c5e51e1fc7daa0180df5af3294177f", null ],
    [ "RSV_BYTE3_RUNT_FILTER_MATCH", "group__rsv_bits.html#gaf4ae3b272d5eb92f8d38f183846445b3", null ],
    [ "RSV_BYTE4_HASH_FILTER_MATCH", "group__rsv_bits.html#ga68476e62976ec265592a312ba2aefab1", null ],
    [ "RSV_BYTE4_MAGIC_PACKET_FILTER_MATCH", "group__rsv_bits.html#ga8fc9b8804e9cb35a7c8ae4b5bc5065c1", null ],
    [ "RSV_BYTE4_NOT_ME_FILTER_MATCH", "group__rsv_bits.html#ga27160ef6ffdcaa803c8ca26cb1c95499", null ],
    [ "RSV_BYTE4_PATTERN_MATCH_FILTER_MATCH", "group__rsv_bits.html#ga81251d8615bd5ed24a75cc03a4803e3f", null ],
    [ "RSV_BYTE4_UNICAST_FILTER_MATCH", "group__rsv_bits.html#gab864c929aa2a7b2423d54ff554356355", null ]
];