var group__single__byte =
[
    [ "B0SEL", "group__single__byte.html#ga6239793585f937e37e61eda071508b40", null ],
    [ "B1SEL", "group__single__byte.html#gab360ee4ad696c1bdd05618a6fb93747b", null ],
    [ "B2SEL", "group__single__byte.html#ga0c5d34eed61b9f41eb229d1296553fa3", null ],
    [ "B3SEL", "group__single__byte.html#ga3f5b541c613dad477a8d90e10a7b8a55", null ],
    [ "CLREIE", "group__single__byte.html#gaefaf2ed14e418c07c6587043c0ecd0f9", null ],
    [ "DISABLERX", "group__single__byte.html#ga71b0c6c4ecdcb0051588c13101e9b282", null ],
    [ "DMACKSUM", "group__single__byte.html#ga129e533bb06e3aa1641c9172edb56494", null ],
    [ "DMACKSUMS", "group__single__byte.html#ga4c98f8a75ecaf7988fd864f65ee89c00", null ],
    [ "DMACOPY", "group__single__byte.html#ga907bfb223f682a2f91b6007155a0adac", null ],
    [ "DMACOPYS", "group__single__byte.html#ga05a3e15f88f8e268907b2ec12420433a", null ],
    [ "DMASTOP", "group__single__byte.html#ga6cda58c4a10d34c851230fc3ea7eaf1a", null ],
    [ "ENABLERX", "group__single__byte.html#ga54713734b9ae7ae4e95e8a9e41a2a2cf", null ],
    [ "FCCLEAR", "group__single__byte.html#ga9d7f9a8ede2963dbd00699d9244fd18a", null ],
    [ "FCDISABLE", "group__single__byte.html#ga1acab7510b4236c7e4376439a8ffe154", null ],
    [ "FCMULTIPLE", "group__single__byte.html#gac545b2d639c3967af4c1150334952fb4", null ],
    [ "FCSINGLE", "group__single__byte.html#ga2d69e97099b83953d2e87b73f1b892cd", null ],
    [ "SETEIE", "group__single__byte.html#ga18fb24806c923f20700c651f0db72a57", null ],
    [ "SETETHRST", "group__single__byte.html#ga8763648ea939c9f6494cca43828dcc0c", null ],
    [ "SETPKTDEC", "group__single__byte.html#gab4cdb8940073f2025cab184a4215510f", null ],
    [ "SETTXRTS", "group__single__byte.html#ga889d3bef89093b4c5a113384ed539052", null ]
];