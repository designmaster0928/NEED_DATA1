var group__ethernet_controller =
[
    [ "ENC424J600", "group__enc424j600__module.html", "group__enc424j600__module" ],
    [ "LEDs", "group__leds.html", "group__leds" ],
    [ "Data Transmission", "group__data__transmission.html", "group__data__transmission" ],
    [ "Data Reception", "group__data__reception.html", "group__data__reception" ]
];