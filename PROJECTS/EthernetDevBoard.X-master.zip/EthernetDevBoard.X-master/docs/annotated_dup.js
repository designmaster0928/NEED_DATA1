var annotated_dup =
[
    [ "ARP_message", "struct_a_r_p__message.html", "struct_a_r_p__message" ],
    [ "ARP_tableEntry", "struct_a_r_p__table_entry.html", "struct_a_r_p__table_entry" ],
    [ "backgroundTaskHandler", "structbackground_task_handler.html", "structbackground_task_handler" ],
    [ "error", "structerror.html", "structerror" ],
    [ "ethernetConnection", "structethernet_connection.html", "structethernet_connection" ],
    [ "ethernetFrame", "structethernet_frame.html", "structethernet_frame" ],
    [ "interruptFlags", "structinterrupt_flags.html", "structinterrupt_flags" ],
    [ "ipv4_address", "structipv4__address.html", "structipv4__address" ],
    [ "ipv4_header", "structipv4__header.html", "structipv4__header" ],
    [ "ipv4_packet", "structipv4__packet.html", "structipv4__packet" ],
    [ "macaddress", "structmacaddress.html", "structmacaddress" ],
    [ "memoryField", "structmemory_field.html", "structmemory_field" ],
    [ "RSV", "struct_r_s_v.html", "struct_r_s_v" ],
    [ "stack", "structstack.html", "structstack" ]
];