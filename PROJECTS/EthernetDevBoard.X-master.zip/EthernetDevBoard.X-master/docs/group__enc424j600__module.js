var group__enc424j600__module =
[
    [ "Initialisation", "group__init.html", "group__init" ],
    [ "Transmission", "group__transmission.html", "group__transmission" ],
    [ "Reception", "group__reception.html", "group__reception" ],
    [ "Pointer operations", "group__pointers.html", "group__pointers" ],
    [ "Settings", "group__settings.html", "group__settings" ],
    [ "Interrupts", "group__interrupts.html", "group__interrupts" ],
    [ "Hardware actions", "group___h_a_r_d_w_a_r_e___a_c_t_i_o_n_s.html", "group___h_a_r_d_w_a_r_e___a_c_t_i_o_n_s" ],
    [ "Registers", "group__registers.html", "group__registers" ],
    [ "Single Byte Instructions", "group__single__byte.html", "group__single__byte" ],
    [ "DEVICE_NAME", "group__enc424j600__module.html#ga5f5a2c9450ebc584b4fe743c6b1a280b", null ]
];