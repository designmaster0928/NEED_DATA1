var group__phy =
[
    [ "ENC424J600_readPHYRegister", "group__phy.html#ga7c3e9522ad9de6093fdf0ccf33e0b580", null ]
];