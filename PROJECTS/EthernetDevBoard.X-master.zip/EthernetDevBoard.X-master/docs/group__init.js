var group__init =
[
    [ "ENC424J600_initSPI", "group__init.html#ga513545639af2de051e63c900009eb4ff", null ],
    [ "ethernetController_checkDeviceId", "group__init.html#ga67521cdab8bfce49cee40d037a888793", null ],
    [ "ethernetController_clearInterruptFlag", "group__init.html#ga472d2ba5053ebbb349e514699adfcde3", null ],
    [ "ethernetController_disableEthernet", "group__init.html#gaadd13e81fe0097411b3aae2f6810bbe1", null ],
    [ "ethernetController_disableReception", "group__init.html#ga9cb4657907d3985ecf5b867f7a8a9304", null ],
    [ "ethernetController_disableTransmission", "group__init.html#ga7cb7d48ac9c1a7bd6393c95e6e07dcee", null ],
    [ "ethernetController_enableEthernet", "group__init.html#ga06ef512fd11e36bbefaad96993875d2b", null ],
    [ "ethernetController_enableReception", "group__init.html#ga203eb473ea1d221ffe97839b16e74565", null ],
    [ "ethernetController_enableTransmission", "group__init.html#ga0aef586bd9434125367071595a794806", null ],
    [ "ethernetController_getDeviceName", "group__init.html#gae396f51c0fdba634e4e84b5f2b5d9416", null ],
    [ "ethernetController_getMTU", "group__init.html#gabb37702e7cfbd10dc932ca6502fd7bae", null ],
    [ "ethernetController_getSiliconRevision", "group__init.html#gaa3396c9822f00c6519a0e7a421048a71", null ],
    [ "ethernetController_init", "group__init.html#ga440a9f27fc612a678d3d17eb5983c977", null ],
    [ "ethernetController_pollInterruptFlags", "group__init.html#ga5cdd5a8c6a5ceab1292643f291137bd1", null ],
    [ "ethernetController_softReset", "group__init.html#ga6a772ec407e60e921bad4db7a2be2676", null ],
    [ "ethernetController_updateLinkStatus", "group__init.html#gab294a8fbc5b11d40a5da5e769110f6ca", null ]
];