var group___s_f_rs =
[
    [ "Bank 0 Instructions", "group___b_a_n_k__0.html", "group___b_a_n_k__0" ],
    [ "Bank 1 Instructions", "group___b_a_n_k__1.html", "group___b_a_n_k__1" ],
    [ "Bank 2 Instructions", "group___b_a_n_k__2.html", "group___b_a_n_k__2" ],
    [ "Bank 3 Instructions", "group___b_a_n_k__3.html", "group___b_a_n_k__3" ],
    [ "Unbanked Instructions", "group___b_a_n_k___u_n.html", "group___b_a_n_k___u_n" ]
];