var group__memory =
[
    [ "memoryField", "structmemory_field.html", [
      [ "end", "structmemory_field.html#afbcd798d035e37e733b567c2b0cb96dc", null ],
      [ "fIsAssigned", "structmemory_field.html#a36ed4d8e7e2e5f308044e7b422a80028", null ],
      [ "fOutOfMemory", "structmemory_field.html#a90bc80d5fb22db8fba7b5601b9336395", null ],
      [ "index", "structmemory_field.html#aae5a12e607d0f782506d9e6ec6179c64", null ],
      [ "length", "structmemory_field.html#a1892eba2086d12ac2b09005aeb09ea3b", null ],
      [ "start", "structmemory_field.html#a171a2b5d11b1a5891c38a98ac731a161", null ]
    ] ],
    [ "END_OF_MEMORY_ADDRESS", "group__memory.html#gad2770fc418de68b3967d98142954405a", null ],
    [ "NUMBER_OF_MEMORY_FIELDS", "group__memory.html#ga31efd827f5e76320608065c79fc29e00", null ],
    [ "RX_DATA_START_ADDRESS", "group__memory.html#gab75619e07ad50e2b4b78684bd3dc81df", null ],
    [ "TX_DATA_START_ADDRESS", "group__memory.html#gaf952470b2ca20106b4998e400ac4236e", null ],
    [ "memoryField_t", "group__memory.html#ga1d04d80fae40964f55d2df46b5d64785", null ],
    [ "checkForOverlap", "group__memory.html#ga9ad1cd676b77e121ddbc6f0f9a5623a5", null ],
    [ "checkForOverlapSwitched", "group__memory.html#ga83197930496e5f94e329db12ab12ae3a", null ],
    [ "memory_txFrameClear", "group__memory.html#ga8b2a265d683cd262c1a0aa1fcb847f75", null ],
    [ "memory_txFrameRequest", "group__memory.html#ga8efe1d17c78d178ef11effad448b1041", null ]
];