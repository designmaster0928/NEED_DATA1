var group__registers =
[
    [ "Read/Write Registers", "group__readwrite.html", "group__readwrite" ],
    [ "PHY Registers", "group__phy.html", "group__phy" ],
    [ "Special Function Registers Definitions", "group___s_f_rs.html", "group___s_f_rs" ]
];