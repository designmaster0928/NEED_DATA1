var group__background =
[
    [ "backgroundTaskHandler", "structbackground_task_handler.html", [
      [ "err", "structbackground_task_handler.html#a79e8f977787d9fccf257bbbccaaf3522", null ],
      [ "fPacketPending", "structbackground_task_handler.html#a55a5ad03a1e3f5808b419c49021b4759", null ],
      [ "interruptFlags", "structbackground_task_handler.html#a58c597d1c6de0f01d960436216389529", null ]
    ] ],
    [ "backgroundTaskHandler_t", "group__background.html#gac2e383293fae75d74beedf63afefe604", null ],
    [ "handleStackBackgroundTasks", "group__background.html#gaf6bebfbbcd06181803783d2504fe318e", null ]
];