var group__system =
[
    [ "LEDs", "group__system.html#ga77b43ba2ffc269c4f3913a1637d82511", null ],
    [ "LEDState", "group__system.html#ga9cbef44d3b130fd1d9e72df4bbdf3b7c", null ],
    [ "LEDs_", "group__system.html#gaebaf57c02081bccf60547d46021b70e0", [
      [ "LEDA", "group__system.html#ggaebaf57c02081bccf60547d46021b70e0a511e0f56399fbaa806332616cfbb5c89", null ],
      [ "LEDB", "group__system.html#ggaebaf57c02081bccf60547d46021b70e0a6b84a5ce4060faf1567b08a007809c19", null ]
    ] ],
    [ "LEDState_", "group__system.html#ga3e2aa953691fa023b1828e4260eb85bf", [
      [ "LED_ON", "group__system.html#gga3e2aa953691fa023b1828e4260eb85bfadd01b80eb93658fb4cf7eb9aceb89a1d", null ],
      [ "LED_OFF", "group__system.html#gga3e2aa953691fa023b1828e4260eb85bfafc0ca8cc6cbe215fd3f1ae6d40255b40", null ],
      [ "LED_TRANSMIT_RECEIVE_EVENTS", "group__system.html#gga3e2aa953691fa023b1828e4260eb85bfad40236117a0954a381c6e300bda11ed3", null ]
    ] ]
];