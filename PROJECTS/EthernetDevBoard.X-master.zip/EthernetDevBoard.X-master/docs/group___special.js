var group___special =
[
    [ "BANK_0_OFFSET", "group___special.html#ga66d34711bf1b18dddae4db092c250451", null ],
    [ "BANK_1_OFFSET", "group___special.html#gae57b98d650d14147609e03fc9a65cd02", null ],
    [ "BANK_2_OFFSET", "group___special.html#ga8b7a13bb9d4e800d9780f7dd7e1fb7a1", null ],
    [ "BANK_3_OFFSET", "group___special.html#gafe3718fe6c607fc8c48e91ad5f2787b2", null ]
];