var group__readwrite =
[
    [ "ENC424J600_readControlRegisterUnbanked", "group__readwrite.html#ga8c94cbab6de00b8a8d13adea143c6f38", null ],
    [ "ENC424J600_readSingleByte", "group__readwrite.html#gab61318cc26ab8a83826175c17977e98a", null ],
    [ "ENC424J600_readSPI", "group__readwrite.html#ga4ebaa994b5c690f21b1cdf00a7b68d72", null ],
    [ "ENC424J600_writeControlRegisterUnbanked", "group__readwrite.html#ga423ce873600e7d362164e72a044a1772", null ],
    [ "ENC424J600_writeSingleByte", "group__readwrite.html#ga797103a0dadff2ca5a595ff8e7b709c3", null ],
    [ "ENC424J600_writeSPI", "group__readwrite.html#gaf5c60e73677483a3f3ad207d810913ea", null ]
];