var dir_794c70a45455c31bdd8acfc0495e2fb4 =
[
    [ "memoryController.c", "memory_controller_8c.html", "memory_controller_8c" ],
    [ "memoryController.h", "memory_controller_8h.html", "memory_controller_8h" ],
    [ "memoryTypes.h", "memory_types_8h.html", "memory_types_8h" ]
];