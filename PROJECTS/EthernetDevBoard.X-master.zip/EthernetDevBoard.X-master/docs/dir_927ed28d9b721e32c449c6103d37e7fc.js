var dir_927ed28d9b721e32c449c6103d37e7fc =
[
    [ "protocols", "dir_c169aa34bba56761d45880fcbed5ac0b.html", "dir_c169aa34bba56761d45880fcbed5ac0b" ],
    [ "backgroundTasks.c", "background_tasks_8c.html", "background_tasks_8c" ],
    [ "backgroundTasks.h", "background_tasks_8h.html", "background_tasks_8h" ],
    [ "backgroundTasksTypes.h", "background_tasks_types_8h.html", "background_tasks_types_8h" ],
    [ "bool.h", "bool_8h.html", "bool_8h" ],
    [ "error.h", "error_8h.html", "error_8h" ],
    [ "stack.c", "stack_8c.html", "stack_8c" ],
    [ "stack.h", "stack_8h.html", "stack_8h" ]
];