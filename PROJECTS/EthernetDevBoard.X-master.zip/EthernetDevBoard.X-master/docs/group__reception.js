var group__reception =
[
    [ "Receive Status Vector", "group__rsv.html", "group__rsv" ],
    [ "ENC424J600_getNextPacketPointer", "group__reception.html#ga2c1dea4bf2f8394aa3b74219deb101c5", null ],
    [ "ENC424J600_getPacketCount", "group__reception.html#gaa13e1b8c5db3af642d8c2f3aa9c10023", null ],
    [ "ENC424J600_setNextPacketPointer", "group__reception.html#ga5cfa4f68ec24587ef646ec3ad8a45aae", null ]
];