var background_tasks_types_8h =
[
    [ "backgroundTaskHandler_t", "group__background.html#gac2e383293fae75d74beedf63afefe604", null ]
];