var ethernet_8h =
[
    [ "ethernet_rxGetNewFrame", "group__ethernet.html#ga70be1735d8cd38033d7162e7d94d1eeb", null ],
    [ "ethernet_txFrameRequest", "group__ethernet.html#ga65c7184e84b9d43ceb53481b6b3dedae", null ]
];