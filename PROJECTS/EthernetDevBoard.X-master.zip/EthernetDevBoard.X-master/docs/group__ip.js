var group__ip =
[
    [ "IPv4 Address operations", "group__ip__operations.html", "group__ip__operations" ],
    [ "ipv4_calculateHeaderChecksum", "group__ip.html#ga09274e15872e0cab31afe677f92a0865", null ],
    [ "ipv4_handleNewPacket", "group__ip.html#ga5de57cac56575029b85390fc8ac1b8ca", null ],
    [ "ipv4_sendFrame", "group__ip.html#ga8bd7900cb9a8af580a2fe0fbb9f559d2", null ],
    [ "ipv4_streamToTransmissionBuffer", "group__ip.html#ga6b56766f821375422e6457b30c26d9f4", null ],
    [ "ipv4_txFrameRequest", "group__ip.html#ga201c03909f1133c33424a0b9a27097cd", null ],
    [ "ipv4_writeHeaderIntoBuffer", "group__ip.html#gae8665fdfac6d01c77647dbc70010bcf7", null ]
];