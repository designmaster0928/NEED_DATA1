var group__settings =
[
    [ "ENC424J600_disableAutoMACInsertion", "group__settings.html#ga9b0dc713146faa5eff449b6ff5d25f0d", null ],
    [ "ENC424J600_enableAutoMACInsertion", "group__settings.html#ga48a2d20fbe876c0da2c3c4ec054caf68", null ],
    [ "ENC424J600_enableReception", "group__settings.html#ga61714295089c9ee4954efbb654faed48", null ]
];