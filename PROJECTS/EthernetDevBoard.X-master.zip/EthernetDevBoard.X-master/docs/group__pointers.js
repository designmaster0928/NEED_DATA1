var group__pointers =
[
    [ "ENC424J600_setERXDATAReadPointer", "group__pointers.html#ga59982003b7e62d4bab901ffd195a36b5", null ],
    [ "ENC424J600_setGPDATAReadPointer", "group__pointers.html#gae03b20d36b3ae985b8fd136a8c79a700", null ],
    [ "ENC424J600_setGPDATAWritePointer", "group__pointers.html#ga9c47ce71f13c5a24ad656f1d95a5ddf9", null ],
    [ "ENC424J600_setRXBufferStartAddress", "group__pointers.html#ga70142ad5c8ccbf36a517de35222a8539", null ],
    [ "ENC424J600_setRXTailPointer", "group__pointers.html#ga8ee6b72fc5e5276cc662a01765e872f8", null ],
    [ "ENC424J600_setTXStartAddress", "group__pointers.html#gab75ffb7fda4db9b424e55d4521b37ff4", null ]
];