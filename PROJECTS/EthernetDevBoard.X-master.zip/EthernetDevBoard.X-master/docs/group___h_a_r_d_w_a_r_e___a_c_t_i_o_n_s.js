var group___h_a_r_d_w_a_r_e___a_c_t_i_o_n_s =
[
    [ "CS_PIN_HIGH", "group___h_a_r_d_w_a_r_e___a_c_t_i_o_n_s.html#ga0113abc1907a59045f1cb1c5541f3aac", null ],
    [ "CS_PIN_LOW", "group___h_a_r_d_w_a_r_e___a_c_t_i_o_n_s.html#ga86b6db148222b2e6c27f50ade652aed0", null ]
];