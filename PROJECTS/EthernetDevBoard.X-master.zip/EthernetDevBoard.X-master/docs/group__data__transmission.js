var group__data__transmission =
[
    [ "ethernetController_sendPacket", "group__data__transmission.html#gacab51e5c9afa0f0b90e6694bcfc7d936", null ],
    [ "ethernetController_streamToTransmitBuffer", "group__data__transmission.html#ga9c0d9b39642cf6b7e220b9f0b44e3e02", null ],
    [ "ethernetController_writeDestinationMACAddress", "group__data__transmission.html#ga858fd557b9ef00b3fd8166381e415bec", null ],
    [ "ethernetController_writeEtherTypeFieldToBuffer", "group__data__transmission.html#ga8fa7a1c372901218a6c545df21fc9ef3", null ]
];