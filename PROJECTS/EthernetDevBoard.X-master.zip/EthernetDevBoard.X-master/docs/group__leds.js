var group__leds =
[
    [ "LEDs", "group__leds.html#gab6831a7d06c0a2bc69f9b024f6445a80", [
      [ "LEDA", "group__leds.html#ggab6831a7d06c0a2bc69f9b024f6445a80a511e0f56399fbaa806332616cfbb5c89", null ],
      [ "LEDB", "group__leds.html#ggab6831a7d06c0a2bc69f9b024f6445a80a6b84a5ce4060faf1567b08a007809c19", null ]
    ] ],
    [ "LEDStates", "group__leds.html#gadb7024cd315c36db7da7879b037a2e21", [
      [ "LED_ON", "group__leds.html#ggadb7024cd315c36db7da7879b037a2e21add01b80eb93658fb4cf7eb9aceb89a1d", null ],
      [ "LED_OFF", "group__leds.html#ggadb7024cd315c36db7da7879b037a2e21afc0ca8cc6cbe215fd3f1ae6d40255b40", null ],
      [ "LED_TRANSMIT_RECEIVE_EVENTS", "group__leds.html#ggadb7024cd315c36db7da7879b037a2e21ad40236117a0954a381c6e300bda11ed3", null ]
    ] ],
    [ "ethernetController_setLEDConfiguration", "group__leds.html#ga3ec0343a266cb8a4925097d708dd96f4", null ],
    [ "ethernetController_setLEDStatus", "group__leds.html#ga88905c196e37262340f8404fcb61ecf9", null ]
];