var group__data__reception =
[
    [ "LEDs", "group__leds.html", "group__leds" ],
    [ "LED_OFF", "group__leds.html#ggadb7024cd315c36db7da7879b037a2e21afc0ca8cc6cbe215fd3f1ae6d40255b40", null ],
    [ "LED_ON", "group__leds.html#ggadb7024cd315c36db7da7879b037a2e21add01b80eb93658fb4cf7eb9aceb89a1d", null ],
    [ "LED_TRANSMIT_RECEIVE_EVENTS", "group__leds.html#ggadb7024cd315c36db7da7879b037a2e21ad40236117a0954a381c6e300bda11ed3", null ],
    [ "LEDA", "group__leds.html#ggab6831a7d06c0a2bc69f9b024f6445a80a511e0f56399fbaa806332616cfbb5c89", null ],
    [ "LEDB", "group__leds.html#ggab6831a7d06c0a2bc69f9b024f6445a80a6b84a5ce4060faf1567b08a007809c19", null ],
    [ "ethernetController_dropPacket", "group__data__reception.html#gada8fcdc667d1800b5f963bfc8cea56c2", null ],
    [ "ethernetController_getCurrentPacketCount", "group__data__reception.html#ga0ab2398cb48efd9a8943a5c5b2872b0c", null ],
    [ "ethernetController_getDestinationMACAddress", "group__data__reception.html#ga29e5c29891e62206ceed99a6b15749a0", null ],
    [ "ethernetController_getEtherTypeField", "group__data__reception.html#gae806930e1cc431f556f805fe1aef6355", null ],
    [ "ethernetController_getMacAddress", "group__data__reception.html#gae3335ee23b52ab5086b95f83127b755c", null ],
    [ "ethernetController_getNextPacketPointer", "group__data__reception.html#ga6155805a8511681932051b00a0032f9f", null ],
    [ "ethernetController_getRSV", "group__data__reception.html#ga1d8cfd56b6020b891ba408c18789129c", null ],
    [ "ethernetController_getSourceMACAddress", "group__data__reception.html#gaa299c646a9c07c0ee81e8c673acd56b2", null ],
    [ "ethernetController_newPacketAvailable", "group__data__reception.html#gae030bd0d97a72b4c38d3ac55132dd7f3", null ],
    [ "ethernetController_setMacAddress", "group__data__reception.html#ga4856965b47df99d3532a7d1cbb494e02", null ],
    [ "ethernetController_streamFromRXBuffer", "group__data__reception.html#ga5748b4be9f5e6936ab91753411a440d9", null ]
];