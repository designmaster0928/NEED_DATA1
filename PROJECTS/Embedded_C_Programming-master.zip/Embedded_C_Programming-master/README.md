# Embedded_C_Programming
various embedded c program/project codes under different concept
