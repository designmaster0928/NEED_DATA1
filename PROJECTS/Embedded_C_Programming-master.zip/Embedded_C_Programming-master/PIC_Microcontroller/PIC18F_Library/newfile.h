#ifndef __Keypad_H
void BCD_to_ASCII_Display(unsigned char Digit);
void RTC_init(void);
void RTC_read(void);

#endif
