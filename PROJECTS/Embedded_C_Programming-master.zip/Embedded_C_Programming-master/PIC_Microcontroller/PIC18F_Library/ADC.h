#ifndef __ADC_H
#define __ADC_H

void ADC_Init(void);                    // Init ADC peripheral
unsigned int ADC_Conversion (unsigned char Channel);

#endif
