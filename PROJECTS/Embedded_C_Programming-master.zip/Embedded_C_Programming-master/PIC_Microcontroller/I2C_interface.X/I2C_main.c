//I2C interface

#include <xc.h>
void i2c_init()
{
    
}
void main(void) {
    return;
}
