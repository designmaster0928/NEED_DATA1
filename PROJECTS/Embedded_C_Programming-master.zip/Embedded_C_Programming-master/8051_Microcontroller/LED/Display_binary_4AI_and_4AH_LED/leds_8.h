void disp_bin_LEDs(char);
