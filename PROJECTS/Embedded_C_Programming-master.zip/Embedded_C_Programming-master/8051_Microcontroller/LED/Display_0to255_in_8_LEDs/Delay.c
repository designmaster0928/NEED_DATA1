void ms_delay(int time)
{
	int i,j;
	for(i=0;i<time;i++)
		for(j=0;j<113;j++);
}