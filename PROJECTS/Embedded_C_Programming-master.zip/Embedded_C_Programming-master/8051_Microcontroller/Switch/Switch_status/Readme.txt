write an ECP for display the active low switch status on active high LED.
