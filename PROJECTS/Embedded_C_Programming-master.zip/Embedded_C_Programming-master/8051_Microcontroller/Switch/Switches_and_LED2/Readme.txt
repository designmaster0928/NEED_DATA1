Write a ECP for -

There are two switches and one LED
-switch 1 and switch 2 connected to P1.0 and P1.1
-LED is connected to P1.7

-when any switches is ON,turn ON LED
-otherwise LED turn off.