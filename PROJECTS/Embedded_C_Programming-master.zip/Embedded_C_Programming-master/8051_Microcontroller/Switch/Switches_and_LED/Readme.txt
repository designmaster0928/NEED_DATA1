Write a ECP for -

there are two switches and one LED
switch 1 and switch 2 connected to P1.0 and P1.1
LED is connected to P1.7

only when two switches are ON, LED is turn ON
otherwise LED turn off.