write an ECP for 
- display the count of how many time switch where pressed
- count is in binary format  