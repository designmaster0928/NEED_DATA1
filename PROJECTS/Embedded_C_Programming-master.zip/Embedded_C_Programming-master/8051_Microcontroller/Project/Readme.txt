Time based device control system

-Equipment used
-------------------
1.AT89S52 
2.LCD 
3.SPDT Relay
4.AC Bulb
5.DS1307-RTC
6.AT24C08-EEPROM
7.4X4 Matrix Keypad
8.Green LED
