//write an ECP for displaying ASCII character on alphanumeric LCD

void Init_LCD(void);
void write_cmd_LCD(char);
void write_dat_LCD(char);
void write_int_LCD(signed int);
void write_float_LCD(float);