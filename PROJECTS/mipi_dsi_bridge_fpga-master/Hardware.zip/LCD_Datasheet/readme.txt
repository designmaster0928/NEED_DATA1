LCD Part number is LH154Q01-TD01 if you are willing to source it off internet. searching for ipod nano 6 lcd may turn more results.
