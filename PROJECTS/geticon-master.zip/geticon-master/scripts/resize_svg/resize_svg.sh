inkscape --batch-process --verb "FitCanvasToDrawing;FileSave;FileQuit" icons/*.svg
