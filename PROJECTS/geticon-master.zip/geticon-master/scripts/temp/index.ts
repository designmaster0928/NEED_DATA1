// import fs from 'fs'

// const data =

// const ret = data
//   .map(({ name, shortname, url, files }) => {
//     const _files = files.map((f, i) => ({
//       filename: f,
//       type: i === 0 ? 'icon' : 'logo',
//       source: '$gb',
//     }))
//     return {
//       name,
//       id: shortname,
//       url,
//       files: _files,
//     }
//   })
//   .flat()

// console.log(ret)

// const resultJson = JSON.stringify(ret, null, 2)
// fs.writeFileSync(`./scripts/ret.json`, resultJson)
