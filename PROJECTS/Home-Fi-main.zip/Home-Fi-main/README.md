<p align="center">
<img src="assets/readmeFiles/Home-Fi.png" width=700>
</p>

### A Home Automation app made using Flutter, Adafruit IO & ESP32 Dev Board.

<br>

<a href="https://www.buymeacoffee.com/jobinbiju234" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" height="50px" alt="Buy Me A Coffee"></a>

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.

<br>

# Work in progress

## UI Till Now

| <img align="left" alt="Splash Screen" src="assets/readmeFiles/1_Splash.gif" width="240px" /> | <img align="left" alt="Welcome Screen" src="assets/readmeFiles/2_Dash.jpg" width="240px" /> | <img align="left" alt="Welcome Screen" src="assets/readmeFiles/3_RGB.jpg" width="240px" /> |
| -------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------ |
