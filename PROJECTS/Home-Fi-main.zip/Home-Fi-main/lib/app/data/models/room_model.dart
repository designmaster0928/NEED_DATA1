class Room {
  String roomName;
  String roomImgUrl;

  Room({required this.roomName, required this.roomImgUrl});
}
