
#ifndef __COMMON_H__
#define __COMMON_H__

#define MAJOR_VER		101
#define MINOR_VER		0
#define MAINTENANCE_VER	0

#define APP_BASE		0x08007000			// Boot Size 28K

#define SOCK_CONFIG		0
#define SOCK_TFTP		1

#endif
