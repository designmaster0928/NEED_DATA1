
#ifndef __TIMERHANDLER_H__
#define __TIMERHANDLER_H__

void Timer_Configuration(void);

#endif
