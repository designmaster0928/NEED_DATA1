
#ifndef __DHCP_CB_H__
#define __DHCP_CB_H__

void w5500_dhcp_assign();
void w5500_dhcp_conflict();

#endif
