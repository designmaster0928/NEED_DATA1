/**
 * @file	rccHandler.h
 * @brief	Header File for RCC Handler Example
 * @version 1.0
 * @date	2014/07/15
 * @par Revision
 *			2014/07/15 - 1.0 Release
 * @author	
 * \n\n @par Copyright (C) 1998 - 2014 WIZnet. All rights reserved.
 */

#ifndef __RCCHANDLER_H
#define __RCCHANDLER_H

void RCC_Configuration(void);

#endif

