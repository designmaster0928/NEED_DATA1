/**
 * @file	timerHandler.h
 * @brief	Header File for TIMER Handler Example
 * @version 1.0
 * @date	2014/07/15
 * @par Revision
 *			2014/07/15 - 1.0 Release
 * @author	
 * \n\n @par Copyright (C) 1998 - 2014 WIZnet. All rights reserved.
 */

#ifndef __TIMERHANDLER_H
#define __TIMERHANDLER_H

void Timer_Configuration(void);

#endif

