Keep all the modified libraries in the following directory: 

Instead of ASUS there will be your user name

****************************************************
C:\Users\ASUS\Documents\Arduino\libraries\
****************************************************

If you need to modify any library, modify the libraries in the given directory. Otherwise sketches do not work properly.