echo 'generating html .gz files'
cd main/www
./compress_pages.sh
touch *.gz

