# Cronixie clock usermod

This usermod supports driving the Cronixie M and L clock kits by Diamex.

## Installation 

Compile and upload after adding `-D USERMOD_CRONIXIE` to `build_flags` of your PlatformIO environment.  
Make sure the Auto Brightness Limiter is enabled at 420mA (!) and configure 60 WS281x LEDs.